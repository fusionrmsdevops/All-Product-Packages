﻿using System;
using System.Web;
using System.Web.UI;

public partial class KNBraintreePaymentConnector : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Request.Form["Token"] != null)
            {
                string fullvalue = Request.Form["Token"].ToString();
                string[] separator = new string[] { KBraintree.KBConstants.BTTokenTypeSeparator };
                string[] container = fullvalue.Split(separator, System.StringSplitOptions.RemoveEmptyEntries);
                HFtoken.Value = container[0];
                TranType.Value = container[1];
                TranUID.Value = container[2];

                HttpCookie userInfo = new HttpCookie("userInfo");
                userInfo["TT"] = TranType.Value;
                userInfo["TUID"] = TranUID.Value;
                userInfo.Expires.Add(new TimeSpan(0, 5, 0));
                Response.Cookies.Add(userInfo);
            }
            else
            {
                HttpCookie reqCookies = Request.Cookies["userInfo"];
                if (reqCookies != null)
                {
                    TranType.Value = reqCookies["TT"].ToString();
                    TranUID.Value = reqCookies["TUID"].ToString();
                }
            }
        }
    }
}

