using KNMagentoConnector;
using System;
using System.Drawing;
using System.Web.UI.WebControls;
using PX.Data;

public partial class Page_KNMC1000 : PX.Web.UI.PXPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RegisterStyle("MyCssRed", null, "Red", false);
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        PXGraph graph = this.ds.DataGraph;
        // graph.Clear();

        KNLicense liceneobj = PXSelect<KNLicense, Where<KNLicense.productCode, Equal<Required<KNLicense.productCode>>>>.Select(graph, KNMCConstants.ProductCode);

        if (liceneobj == null)
        {
            hprLicenseLink.Visible = true;
        }

        // For Grace Period
        if (liceneobj != null && liceneobj.LicenseType != "Demo")
        {
            if (!string.IsNullOrEmpty(liceneobj.LVCounter))
            {
                int LVCntrTemp = Convert.ToInt32(liceneobj.LVCounter);
                DateTime LVexpryDate = DateTime.Parse(liceneobj.ExpiryDate);

                if (LVCntrTemp > 0 && LVCntrTemp < 8)
                {
                    lblGraceMessage.Visible = true;
                    hprLicenseLinkUpgrade.Visible = true;
                }
                else
                {
                    hprLicenseLinkUpgrade.Visible = false;
                    lblGraceMessage.Visible = false;
                }
            }
        }
    }

    protected void grid_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e)
    {
        KNMCInitializationDetails item = e.Row.DataItem as KNMCInitializationDetails;
        if (item == null) return;

        if (item.Failed == true)
            e.Row.Style.CssClass = "MyCssRed";
    }

    private void RegisterStyle(string name, string backColor, string foreColor, bool bold)
    {
        Style style = new Style();
        if (!string.IsNullOrEmpty(backColor)) style.BackColor = Color.FromName(backColor);
        if (!string.IsNullOrEmpty(foreColor)) style.ForeColor = Color.FromName(foreColor);
        style.Font.Bold = bold;
        Page.Header.StyleSheet.CreateStyleRule(style, this, "." + name);
    }
}
