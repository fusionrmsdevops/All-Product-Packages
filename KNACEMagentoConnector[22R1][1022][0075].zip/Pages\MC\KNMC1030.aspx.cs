using KNMagentoConnector;
using System;
using System.Drawing;
using System.Web.UI.WebControls;

public partial class Page_KNMC1030 : PX.Web.UI.PXPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RegisterStyle("MyCssRed", null, "Red", false);
    }

    private void RegisterStyle(string name, string backColor, string foreColor, bool bold)
    {
        Style style = new Style();
        if (!string.IsNullOrEmpty(backColor)) style.BackColor = Color.FromName(backColor);
        if (!string.IsNullOrEmpty(foreColor)) style.ForeColor = Color.FromName(foreColor);
        style.Font.Bold = bold;

        this.Page.Header.StyleSheet.CreateStyleRule(style, this, "." + name);
    }

    protected void grid_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e)
    {
        KNMCProductSchemaDetails product = e.Row.DataItem as KNMCProductSchemaDetails;

        if (product != null && product.IsDeleted == true)
        {
            e.Row.Style.CssClass = "MyCssRed";
        }
    }
}
