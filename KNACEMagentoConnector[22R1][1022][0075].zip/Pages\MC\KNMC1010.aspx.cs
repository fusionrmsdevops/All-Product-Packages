using KNMagentoConnector;
using PX.Data;
using System;

public partial class Page_KNMC1010 : PX.Web.UI.PXPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void uploadPanel_Upload(PX.Web.UI.UserControls.PXUploadFilePanel.PXFileUploadedEventArgs e)
    {
        try
        {
            ((KNMCMagentoSetupMaint)ds.DataGraph).UploadData(e.BinData, e.FileName);
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(GetType(), "msgbox", "alert('" + ex.Message.ToString() + "');", true);
        }

    }
}
