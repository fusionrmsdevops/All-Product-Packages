using System;
using KNMagentoConnector;

public partial class Page_KNMC5121 : PX.Web.UI.PXPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
   
}
