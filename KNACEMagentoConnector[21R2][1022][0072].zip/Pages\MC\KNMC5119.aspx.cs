using System;
using KNMagentoConnector;

public partial class Page_KNMC5119 : PX.Web.UI.PXPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void uploadPanel_Upload(PX.Web.UI.UserControls.PXUploadFilePanel.PXFileUploadedEventArgs e)
    {
        try
        {
            ((KNMCBatchProductSyncProcess)ds.DataGraph).UploadData(e.BinData, e.FileName);
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(GetType(), "msgbox", "alert('" + ex.Message.ToString() + "');", true);
        }

    }
}
